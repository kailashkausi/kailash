$(function() {
  //----- OPEN
  $('[data-popup-open]').on('click', function(e) {
    var targeted_popup_class = jQuery(this).attr('data-popup-open');
	$('[data-popup="' + targeted_popup_class + '"]').fadeIn(350);

	e.preventDefault();
  });

  //----- CLOSE
  $('[data-popup-close]').on('click', function(e) {
    var targeted_popup_class = jQuery(this).attr('data-popup-close');
    $('[data-popup="' + targeted_popup_class + '"]').fadeOut(350);

	e.preventDefault();
  });

  $(function() {
    var input = $("#input1");
    var ans = $('#answer1');
    var err = $('#error1');

    //---------- Execute validation check Q1
    $('.validate-btn1').on('click', function(e) {
      if( input.val() == "" || (input.val()).match(/^[A-Za-z]+$/) ){
        input.css("border","red 1px solid");
        ans.text("");
        err.text("Enter a valid input. Ex: 2,7,5,9,5");
      } else {
        input.css("border","green 1px solid");
        err.text("");
      }
      e.preventDefault();
    });

    //--------- Reset Q1
    $('#reset1').on('click', function(e) {
      input.val("");
      input.css("border","#7b7979 1px solid");
      ans.text("");
      err.text("");
      e.preventDefault(); 
    });
  });

  $(function() {
    var input = $("#input2");
    var ans = $('#answer2');
    var err = $('#error2');

    //---------- Execute validation check Q2
    $('.validate-btn2').on('click', function(e) {
      if( input.val() == "" ){
        input.css("border","red 1px solid");
        ans.text("");
        err.text("Enter a valid input. Ex: bamboo");
      } else {
        input.css("border","green 1px solid");
        err.text("");
      }
      e.preventDefault();
    });

    //--------- Reset Q2
    $('#reset2').on('click', function(e) {
      input.val("");
      input.css("border","#7b7979 1px solid");
      ans.text("");
      err.text("");
      e.preventDefault(); 
    });
  });
  
  $(function() {
    var input = $("#input3");
    var ans = $('#answer3');
    var err = $('#error3');

    //---------- Execute validation check Q3
    $('.validate-btn3').on('click', function(e) {
      if( input.val() == "" || (input.val()).match(/^[A-Za-z]+$/) ){
        input.css("border","red 1px solid");
        ans.text("");
        err.text("Enter a valid input. Ex: 2,7,5,9,5");
      } else {
        input.css("border","green 1px solid");
        err.text("");
      }
      e.preventDefault();
    });

    //--------- Reset Q3
    $('#reset3').on('click', function(e) {
      input.val("");
      input.css("border","#7b7979 1px solid");
      ans.text("");
      err.text("");
      e.preventDefault(); 
    });
  });

  $(function() {
    var input = $("#input4");
    var ans = $('#answer4');
    var err = $('#error4');

    //---------- Execute validation check Q4
    $('.validate-btn4').on('click', function(e) {
      if( input.val() == ""){
        input.css("border","red 1px solid");
        ans.text("");
        err.text("Enter a valid input. Ex: 1000");
      } else {
        input.css("border","green 1px solid");
        err.text("");
      }
      e.preventDefault();
    });

    //--------- Reset Q4
    $('#reset4').on('click', function(e) {
      input.val("");
      input.css("border","#7b7979 1px solid");
      ans.text("");
      err.text("");
      e.preventDefault(); 
    });
  });

  $(function() {
    var input = $("#input5");
    var ans = $('#answer5');
    var err = $('#error5');

    //---------- Execute validation check Q5
    $('.validate-btn5').on('click', function(e) {
      if( input.val() == ""){
        input.css("border","red 1px solid");
        ans.text("");
        err.text("Enter a valid input. Ex: Javascript");
      } else {
        input.css("border","green 1px solid");
        err.text("");
      }
      e.preventDefault();
    });

    //--------- Reset Q5
    $('#reset5').on('click', function(e) {
      input.val("");
      input.css("border","#7b7979 1px solid");
      ans.text("");
      err.text("");
      e.preventDefault(); 
    });
  });

  $(function() {
    var input1 = $("#input61");
    var input2 = $("#input62");
    var ans = $('#answer6');
    var err = $('#error6');

    //---------- Execute validation check Q6
    $('.validate-btn6').on('click', function(e) {
      if( input1.val() == "" || input2.val() == "" || input1.val() >= input2.val()){
        input1.css("border","red 1px solid");
        input2.css("border","red 1px solid");
        ans.text("");
        err.text("Enter a valid input. Ex: 4, 9");
      } else {
        input1.css("border","green 1px solid");
        input2.css("border","green 1px solid");
        err.text("");
      }
      e.preventDefault();
    });

    //--------- Reset Q6
    $('#reset6').on('click', function(e) {
      input1.val("");
      input1.css("border","#7b7979 1px solid");
      input2.val("");
      input2.css("border","#7b7979 1px solid");
      ans.text("");
      err.text("");
      e.preventDefault(); 
    });
  });

  $(function() {
    var input1 = $("#input71");
    var input2 = $("#input72");
    var ans = $('#answer7');
    var err = $('#error7');

    //---------- Execute validation check Q7
    $('.validate-btn7').on('click', function(e) {
      if( input1.val() == "" || (input1.val()).match(/^[A-Za-z]+$/) ||  input2.val() == "" || (input2.val()).match(/^[A-Za-z]+$/) ){
        input1.css("border","red 1px solid");
        input2.css("border","red 1px solid");
        ans.text("");
        err.text("Enter a valid input. Ex: 2,7,5,9,5");
      } else {
        input1.css("border","green 1px solid");
        input2.css("border","green 1px solid");
        err.text("");
      }
      e.preventDefault();
    });

    //--------- Reset Q7
    $('#reset7').on('click', function(e) {
      input1.val("");
      input1.css("border","#7b7979 1px solid");
      input2.val("");
      input2.css("border","#7b7979 1px solid");
      ans.text("");
      err.text("");
      e.preventDefault(); 
    });
  });

  $(function() {
    var input = $("#input8");
    var ans = $('#answer8');
    var err = $('#error8');
    //---------- Execute validation check Q8
    $('.validate-btn8').on('click', function(e) {
      if( input.val() == ""){
        input.css("border","red 1px solid");
        ans.text("");
        err.text("Enter a valid input. Ex: 09/08/1997");
      } else {
        inputs.css("border","green 1px solid");
        err.text("");
      }
      e.preventDefault();
    });

    //--------- Reset Q8
    $('#reset8').on('click', function(e) {
      input.val("");
      input.css("border","#7b7979 1px solid");
      ans.text("");
      err.text("");
      e.preventDefault(); 
    });
  });
  
  $(function() {
    var input = $("#input9");
    var ans = $('#answer9');
    var err = $('#error9');

    //---------- Execute validation check Q9
    $('.validate-btn9').on('click', function(e) {
      if( input.val() == ""){
        input.css("border","red 1px solid");
        ans.text("");
        err.text("Enter a valid input. Ex: An elephant");
      } else {
        input.css("border","green 1px solid");
        err.text("");
      }
      e.preventDefault();
    });

    //--------- Reset Q9
    $('#reset9').on('click', function(e) {
      input.val("");
      input.css("border","#7b7979 1px solid");
      ans.text("");
      err.text("");
      e.preventDefault(); 
    });
  });

  $(function() {
    var input = $("#input10");
    var ans = $('#answer10');
    var err = $('#error10');

    //---------- Execute validation check Q10
    $('.validate-btn10').on('click', function(e) {
      if( input.val() == ""){
        input.css("border","red 1px solid");
        ans.text("");
        err.text("Enter a valid input. Ex: Javascript");
      } else {
        input.css("border","green 1px solid");
        err.text("");
      }
      e.preventDefault();
    });

    //--------- Reset Q10
    $('#reset10').on('click', function(e) {
      input.val("");
      input.css("border","#7b7979 1px solid");
      ans.text("");
      err.text("");
      e.preventDefault(); 
    });
  });

});


//---------------------Quick sort
function sort(){
  document.getElementById("answer1").innerHTML = '';
  var input = document.getElementById("input1").value;

  //convert array
  var str_items = input.split(",");
  var items = [];
  for (var count = 0; count < str_items.length; count++) {
    items.push(parseInt(str_items[count]));
  }
  var sortedArray = quickSort(items, 0, items.length - 1);
	
  //convert as string
  var sort_str = sortedArray.join(",");
  document.getElementById("answer1").innerHTML = sort_str;
  console.log(sort_str);
}

//var items = [5,3,7,6,2,9];
function swap(items, leftIndex, rightIndex){
  var temp = items[leftIndex];
  items[leftIndex] = items[rightIndex];
  items[rightIndex] = temp;
}

function partition(items, left, right) {
  var pivot   = items[Math.floor((right + left) / 2)], //middle element
  i = left, //left pointer
  j = right; //right pointer
  while (i <= j) {
    while (items[i] < pivot) {
      i++;
    }
    while (items[j] > pivot) {
      j--;
    }
    if (i <= j) {
      swap(items, i, j); //sawpping two elements
      i++;
      j--;
    }
  }
  return i;
}

function quickSort(items, left, right) {
  var index;
  if (items.length > 1) {
    index = partition(items, left, right); //index returned from partition
    if (left < index - 1) { //more elements on the left side of the pivot
      quickSort(items, left, index - 1);
    }
    if (index < right) { //more elements on the right side of the pivot
      quickSort(items, index, right);
    }
  }
  return items;
}
  

//------------------Subset of string
function subset() {
  document.getElementById("answer2").innerHTML = '';
  var input = document.getElementById("input2").value;
  document.getElementById("answer2").innerHTML = input.sub_String();
}

String.prototype.sub_String = function() {
  var subset = [];
  for (var m = 0; m < this.length; m++) {
    for (var n = m+1; n<this.length+1; n++) {
      subset.push(this.slice(m,n));
    }
  }
  return subset;
}


//-----------------------Largest of five numberss
function largest() {
  document.getElementById("answer3").innerHTML = '';
  var input = document.getElementById("input3").value;
  //convert array
  var str_items = input.split(",");
  var items = [];
  for (var count = 0; count < str_items.length; count++) {
    items.push(parseInt(str_items[count]));
  } 
  var largest = 0;
  for ( var iterator = 0; iterator <= largest; iterator++ ) {
    if (items[iterator] > largest) {
      largest = items[iterator];
    }
  }
  document.getElementById("answer3").innerHTML = largest;
}


//------------------------Sum *3 and *5
function sum() {
  document.getElementById("answer4").innerHTML = '';
  var input = document.getElementById("input4").value;
  var sum = 0;
  for (var x = 0; x < input; x++) {
    if (x % 3 === 0 || x % 5 === 0) {
      sum += x;
    }
  }
  document.getElementById("answer4").innerHTML = sum;
}


//---------------- Starts with Java
function start_spec_str() {
  document.getElementById("answer5").innerHTML = '';
  var input = document.getElementById("input5").value;
  var flag = false;
  if (input.length < 4) {
    flag = false;
  }
  front = input.substring(0, 4);
  if (front == 'Java') {
    flag = true;
  } else {
    flag = false;
  }
  document.getElementById("answer5").innerHTML = flag;
}


//-------------------Numbers in range
function range() {
  document.getElementById("answer6").innerHTML = '';
  var start = document.getElementById('input61').value;
  var end = document.getElementById('input62').value;
  var ans = [];
  for(var i = parseInt(start) + 1; i < end; i++) {
    ans.push(i);
  }
  document.getElementById("answer6").innerHTML = ans;
}

//------------------Common in both arrays
function findCommonElement() {       
  document.getElementById("answer7").innerHTML = '';
  var str1 = document.getElementById('input71').value;
  var str2 = document.getElementById('input72').value;

  var arr1 = str1.split(",");
  var arr2 = str2.split(",");

  var origArr1 = [], origArr2 = [], commonElements = [];

  for( var i = 0; i < arr1.length; i++) {
    origArr1.push(parseInt(arr1[i]));
  }

  for( var j = 0; j < arr2.length; j++) {
    origArr2.push(parseInt(arr2[j]));
  }

  // Loop for array1 
  for(let k = 0; k < origArr1.length; k++) { 
    // Loop for array2 
    for(let l = 0; l < origArr2.length; l++) {      
      // Compare the element of each and every element from both of the arrays 
      if(origArr1[k] === origArr2[l]) {           
        // Return if common element found 
        commonElements.push(origArr1[k]); 
      } 
    } 
  }

  document.getElementById("answer7").innerHTML = commonElements;
};

//--------------- Calculate age
function myAgeValidation() {
 
  var lre = /^\s*/;
  var datemsg = "";
  
  var inputDate = document.getElementById("input8").value;
  inputDate = inputDate.replace(lre, "");
  document.getElementById("input8").value = inputDate;

  datemsg = isValidDate(inputDate);

    if (datemsg != "") {
      document.getElementById("input8").style.border = "red 1px solid";
      document.getElementById("error8").innerHTML = datemsg;
      return;
    } else {
      //Now find the Age based on the Birth Date
      document.getElementById("input8").style.border = "green 1px solid";
      getAge(new Date(inputDate));
    }

}

function getAge(birth) {
  var diff_ms = Date.now() - birth.getTime();
  var age_dt = new Date(diff_ms);   
  document.getElementById("answer8").innerHTML = Math.abs(age_dt.getUTCFullYear() - 1970);
}

function isValidDate(dateStr) {
  var msg = "";
  // Checks for the following valid date formats:
  // MM/DD/YY   MM/DD/YYYY   MM-DD-YY   MM-DD-YYYY
  // Also separates date into month, day, and year variables

  // To require a 2 & 4 digit year entry, use this line instead:
  //var datePat = /^(\d{1,2})(\/|-)(\d{1,2})\2(\d{2}|\d{4})$/;
  // To require a 4 digit year entry, use this line instead:
  var datePat = /^(\d{1,2})(\/|-)(\d{1,2})\2(\d{4})$/;

  var matchArray = dateStr.match(datePat); // is the format ok?
  if (matchArray == null) {
      msg += " Date is not in a valid format.";
      return msg;
  }

  month = matchArray[1]; // parse date into variables
  day = matchArray[3];
  year = matchArray[4];

  
  if (month < 1 || month > 12) { // check month range
      msg = " Month must be between 1 and 12.";
      return msg;
  }

  if (day < 1 || day > 31) {
      msg = " Day must be between 1 and 31.";
      return msg;
  }

  if ((month==4 || month==6 || month==9 || month==11) && day==31) {
      msg = " Month "+month+" doesn't have 31 days!";
      return msg;
  }

  if (month == 2) { // check for february 29th
  var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
  if (day>29 || (day==29 && !isleap)) {
      msg = " February " + year + " doesn't have " + day + " days!";
      return msg;
  }
  }

  if (day.charAt(0) == '0') day= day.charAt(1);
  
  //Incase you need the value in CCYYMMDD format in your server program
  //msg = (parseInt(year,10) * 10000) + (parseInt(month,10) * 100) + parseInt(day,10);
  
  return msg;  // date is valid
}

//-----------------Vowels in string
function vowel_count() {
  document.getElementById("answer9").innerHTML = "";
  var input = document.getElementById("input9").value;
  var vowel_list = 'aeiouAEIOU';
  var vcount = 0;
  for(var x = 0; x < input.length ; x++) {
    if (vowel_list.indexOf(input[x]) !== -1) {
      vcount += 1;
    }
  
  }
  document.getElementById("answer9").innerHTML = vcount;
}

//----------------- # of occurences
function Char_Counts() {
  document.getElementById("answer10").innerHTML = "";
  var input = document.getElementById("input10").value;
  var uchars = {};

  input.replace(/\S/g, function(l){uchars[l] = (isNaN(uchars[l]) ? 1 : uchars[l] + 1);});
  
  document.getElementById("answer10").innerHTML = showProps(uchars);
}

function showProps(obj) {
  return Object.entries(obj).map(([key, value]) => [key +" - " + value  + " "])
    
}